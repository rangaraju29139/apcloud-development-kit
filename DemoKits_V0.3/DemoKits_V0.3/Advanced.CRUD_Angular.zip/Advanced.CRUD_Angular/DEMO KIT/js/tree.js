var tree = {
    "birch": [
        "Birch",
        "Paper Birch"
    ],
    "cedar": [
        "Arborvitae",
        "Cedar",
        "Eastern Redcedar"
    ],
    "fruit": [
        "Apple",
        "Cherry",
        "Hawthorn",
        "Pear"
    ],
    "hickory": [
        "Hickory",
        "Shagbark Hickory"
    ],
    "locust": [
        "Black Locust",
        "Honeylocust"
    ],
    "maple": [
        "Boxelder",
        "Maple",
        "Norway Maple",
        "Red Maple",
        "Silver Maple",
        "Sugar Maple"
    ],
    "oak": [
        "Black Oak",
        "Bur Oak",
        "Oak",
        "Pin Oak",
        "Red Oak",
        "White Oak"
    ],
    "pine": [
        "Austrian Pine",
        "Pine",
        "Pine Other",
        "Red Pine",
        "Scotch Pine",
        "Tamarack",
        "White Pine"
    ],
    "poplar": [
        "Bigtooth Aspen",
        "Cottonwood",
        "Poplar",
        "Quaking Aspen",
        "Willow"
    ],
    "spruce": [
        "Blue Spruce",
        "Norway Spruce",
        "Spruce"
    ],
    "other": [
        "Ash",
        "Ailanthus",
        "Beech",
        "Black Walnut",
        "Brush",
        "Buckthorn",
        "Chestnut",
        "Dogwood",
        "Elm",
        "Hackberry",
        "Linden",
        "Magnolia",
        "Mulberry",
        "Northern Catalpa",
        "Ohio Buckeye",
        "Osage Orange",
        "Sassafras",
        "Sweetgum",
        "Sycamore"
    ]
};

//angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)

angular.module('starter.controllers', [])

//Main Controller
.controller('AppCtrl', function($scope) {})

//Create controller which is used to insert data
.controller('CreateCtrl', function($scope, $http, $ionicPopup) {
  $scope.insertData = function() {
    var sName = document.getElementById('sName').value;
    var sEmail = document.getElementById('sEmailForCreate').value;
    var sPhoneNumber = document.getElementById('sPhoneNumber').value;
    var sAddress = document.getElementById('sAddress').value;
    var sDepartment = document.getElementById('sDepartment').value;
    $http.post("http://localhost:7000/api/insert", {
      "_id": sEmail,
      "sName": sName,
      "sEmail": sEmail,
      "sPhoneNumber": sPhoneNumber,
      "sAddress": sAddress,
      "sDepartment": sDepartment
    }).then(function(response) {
      if (response.data.error == undefined) {
        var alertPopup = $ionicPopup.alert({
          title: 'Data Inserted Successfully!!'
        });
        alertPopup(response.data.error);
      } else {
        var alertPopup = $ionicPopup.alert({
          title: 'Sorry insertion failed. Check your mail !!'
        });
        alertPopup(response.data.error);
      }
    })
  }
})

//Retrive controller for retiving the data based on EmailId
.controller('RetrieveCtrl', function($scope, $stateParams, $http, $rootScope, $ionicPopup) {
  $scope.getList = function() {
    var sEmail = document.getElementById('sEmailForRetrieve').value;
    $http.get("http://localhost:7000/api/retrieveById?sEmail=" + sEmail).then(function(response) {
      if (response.data.error == undefined) {
        $scope.sName = response.data.result.sName;
        $scope.sEmail = response.data.result.sEmail;
        $scope.sPhoneNumber = response.data.result.sPhoneNumber;
        $scope.sAddress = response.data.result.sAddress;
        $scope.sDepartment = response.data.result.sDepartment;
        document.getElementById("hideData").style.display = "block";
      } else {
        var alertPopup = $ionicPopup.alert({
          title: 'Please check entered ID'
        });
        alertPopup(response.data.error);
      }
    });
  }
  $scope.clearData = function() {
    document.getElementById("hideData").style.display = "none";
  }

})

//Update Controller for updating the data
.controller('UpdateCtrl', function($scope, $stateParams, $http, $rootScope, $ionicPopup) {
  $scope.update = function() {
    var sEmail = document.getElementById('sEmail').value;
    $http.get("http://localhost:7000/api/retrieveById?sEmail=" + sEmail).then(function(response) {

      if (response.data.error == undefined) {
        $scope.sName = response.data.result.sName;
        $scope.sEmail = response.data.result.sEmail;
        $scope.sPhoneNumber = response.data.result.sPhoneNumber;
        $scope.sAddress = response.data.result.sAddress;
        $scope.sDepartment = response.data.result.sDepartment;
        document.getElementById("showData").style.display = "block";
      } else {
        var alertPopup = $ionicPopup.alert({
          title: 'Please check entered ID'
        });
        alertPopup(response.data.error);
      }
    });
  }
  $scope.updateData = function() {
    var confirmPopup = $ionicPopup.confirm({
      title: 'Update',
      template: 'Are you sure you want to update data?'
    });
    confirmPopup.then(function(response) {
      if (response) {
        var sName = document.getElementById('sNameUpdated').value;
        var sEmail = document.getElementById('sEmailUpdated').value;
        var sPhoneNumber = document.getElementById('sPhoneNumberUpdated').value;
        var sAddress = document.getElementById('sAddressUpdated').value;
        var sDepartment = document.getElementById('sDepartmentUpdated').value;
        $http.post("http://localhost:7000/api/update", {
          "sName": sName,
          "sEmail": sEmail,
          "sPhoneNumber": sPhoneNumber,
          "sAddress": sAddress,
          "sDepartment": sDepartment
        }).then(function(response) {

        })
      } else {
        console.log('canceled !');
      }
    });
  }
  $scope.clearData = function() {
    document.getElementById("showData").style.display = "none";
  }
})

//Delete Controller for deleting the data using EmailId
.controller('DeleteCtrl', function($scope, $ionicPopup, $http) {
  $scope.deleteData = function() {
    var sEmail = document.getElementById('sEmailDelete').value;
    $http.post("http://localhost:7000/api/delete", {
      "sEmail": sEmail,
    }).then(function(response) {
      if (response.data.error == undefined) {
        var alertPopup = $ionicPopup.alert({
          title: 'Data Removed Successfully'
        });
        alertPopup(response.data.error);
      } else {
        var alertPopup = $ionicPopup.alert({
          title: 'Please check entered ID'
        });
        alertPopup(response.data.error);
      }
    });
  }
})

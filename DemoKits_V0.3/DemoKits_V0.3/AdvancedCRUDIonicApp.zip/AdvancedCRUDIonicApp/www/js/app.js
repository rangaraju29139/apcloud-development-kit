// Ionic Starter App

// angular.module is a global place for creating, registering and retrieving Angular modules
// 'starter' is the name of this angular module example (also set in a <body> attribute in index.html)
// the 2nd parameter is an array of 'requires'
// 'starter.controllers' is found in controllers.js
angular.module('starter', ['ionic', 'starter.controllers', 'ngCordova'])

.run(function($ionicPlatform) {
  $ionicPlatform.ready(function() {
// Hide the accessory bar by default (remove this to show the accessory bar above the keyboard
// for form inputs)
    if (window.cordova && window.cordova.plugins.Keyboard) {
// Don't remove this line unless you know what you are doing. It stops the viewport
// from snapping when text inputs are focused. Ionic handles this internally for
// a much nicer keyboard experience.
      cordova.plugins.Keyboard.hideKeyboardAccessoryBar(true);
      cordova.plugins.Keyboard.disableScroll(true);

    }
    if (window.StatusBar) {
// org.apache.cordova.statusbar required
      StatusBar.styleDefault();
    }
  });
})

//config used Page redirection i.e, ui-router

.config(function($stateProvider, $urlRouterProvider) {
  $stateProvider

    .state('app', {
    url: '/app',
    abstract: true,
    templateUrl: 'templates/menu.html',
    controller: 'AppCtrl'
  })

  //Create Navigator

  .state('app.create', {
    url: '/create',
    views: {
      'menuContent': {
        templateUrl: 'templates/Create.html',
        controller: 'CreateCtrl'
      }
    }
  })

  //Retrive Navigator

  .state('app.retrieve', {
    url: '/retrieve',
    views: {
      'menuContent': {
        templateUrl: 'templates/Retrieve.html',
        controller: 'RetrieveCtrl'
      }
    }
  })

//Update Navigator
  .state('app.update', {
    url: '/update',
    views: {
      'menuContent': {
        templateUrl: 'templates/Update.html',
        controller: 'UpdateCtrl'
      }
    }
  })

  //Delete Navigator

  .state('app.delete', {
    url: '/delete',
    views: {
      'menuContent': {
        templateUrl: 'templates/Delete.html',
        controller: 'DeleteCtrl'
      }
    }
  })

  // if none of the above states are matched, use this as the fallback
  $urlRouterProvider.otherwise('/app/create');
});
